import sqlite3
import os
import datetime

db_path='g:/sqlite/'
db_file='db11.db'
full_path=os.path.join(db_path,db_file)

con=sqlite3.connect(full_path)
cur=con.cursor()
sql='''\
	INSERT INTO author (name_author, descr_author)
	VALUES ("Чуковский", "Автор множества книг для детей")
	'''
cur.execute(sql)
con.commit()          # Завершаем транзакцию
cur.close()               # Закрываем объект-курсор
con.close()               # Закрываем соединение
 