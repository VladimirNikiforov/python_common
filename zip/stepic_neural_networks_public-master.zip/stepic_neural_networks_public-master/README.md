# stepic_neural_networks_public
Дополнительные, вспомогательные и вообще разные материалы к курсу «Нейронные сети» на Stepic.Org
